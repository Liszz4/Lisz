/*
   BUY NO ENC SC MYOKU MD V2.8
   BISA HUBUNGI NOMOR SAYA 
   085813708397
10.000 per update 
15.000 free 2 kali update
25.000 free 3 kali update + bisa request Fitur 
35.000 free 4 kali update + Bisa request Fitur

BUY NO ENC SC MYOKU MD V2.8
   BISA HUBUNGI NOMOR SAYA 
   085813708397
   
*/

const fs = require('fs')
const chalk = require('chalk')

global.apikey = '-' // LOLHUMAN Isi pake apikey lu agar Fitur confess bisa diakses
global.rosekey = '-' // ROSE
global.xzn = '-' // isi apikey mu agar bisa mengakses openai 
global.beta = '-' // Isi apikey mu agar bisa diakses 

//—————「 Set Nama Bot & Own 」—————//
global.namabot = 'ᴍʏᴏᴋᴜ ᴍᴅ'
global.namaowner = 'ғᴀʟʟᴢx'

//—————「 Setting Owner 」—————//
global.owner = ['6285813708397']
global.nomerowner = '6285813708397'
global.premium = ['6285813708397']

//—————「 Set Wm 」—————//
global.packname = 'By FallZx\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'
global.author = '𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰 𝚂𝚄𝙱𝚂𝙲𝚁𝙸𝙱𝙴\n𝚈𝚃:FallXD425'
global.prefa = ['', '.']
global.sp = '•'

//—————「 Set Message 」—————//
global.mess = {
    success: '🤗Done, Oke Desu~',
    admin: '❗Perintah Ini Hanya Bisa Digunakan Oleh Admin Group !',
    botAdmin: '❗Perintah Ini Hanya Bisa Digunakan Ketika Bot Menjadi Admin Group !',
    owner: '❗Perintah Ini Hanya Bisa Digunakan Oleh Owner !',
    group: '❗Perintah Ini Hanya Bisa Digunakan Di Group Chat !',
    private: '❗Perintah Ini Hanya Bisa Digunakan Di Private Chat !',
    bot: '🤖 Fitur Khusus Pengguna Nomor Bot !',
    wait: '⏳ Sedang Di Proses !',
    endLimit: '🕊️ Limit Harian Anda Telah Habis, Limit Akan Direset Setiap Jam 12 !',
    error: '🚫 Fitur Sedang Error !',
}

//—————「 Set Limit 」—————//
global.limitawal = {
    premium: "Infinity",
    free: 50
}

//—————「 Set Image 」—————//
global.imageurl = 'https://telegra.ph/file/6d78dbc8e389cf01b79cf.jpg'
global.link = 'https://youtube.com/@FallXD425'
global.thumb = fs.readFileSync('./media/thumb.jpg')

//—————「 Batas Akhir 」—————//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})
